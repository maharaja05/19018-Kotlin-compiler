# Kotlin-Interpreter
A interpreter of Kotlin the programming language.

## New version
There is a new version of this project made in [Rust](https://www.rust-lang.org/) at [kotlin-interpreter-rs](https://github.com/cout970/kotlin-interpreter-rs)
