package com.cout970.ps.lexer

/**
 * Created by cout970 on 2016/09/22.
 */
class DuplicatedElementException(str: String) : RuntimeException(str)