package com.cout970.ps.components

/**
 * Created by cout970 on 2016/09/21.
 */
class CompPackage(val path: String)