package com.cout970.ps.components

/**
 * Created by cout970 on 2016/09/22.
 */
class CompFun(val name: String, vararg args: CompFunArg)