package com.cout970.ps.tokenizer

/**
 * Created by cout970 on 2016/09/22.
 */
interface ITokenStream {

    fun readToken(): Token
}